#include <iostream>

using namespace std;
int sum;

void move(char left, char right)
{
	cout << left << "-->" << right << endl;
}

void hanoi(int n, char lef, char mi, char righ)
{
	++sum;
	if (n == 1)
	{
		cout << lef << "-->" << righ << endl;
	}
	else
	{
		hanoi(n - 1, lef, righ, mi);
		move(lef, righ);
		hanoi(n - 1, mi, lef, righ);
	}
}
int main()
{
	int n;
	cout << "Input n = ";
	cin >> n;
	cout << "The steps to move " << n << " desks:" << endl;
	hanoi(n, 'A', 'B', 'C');
	cout << "The sum of the steps is " << sum << endl;
	return 0;
}